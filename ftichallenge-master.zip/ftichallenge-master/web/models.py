from django.db import models
from django.urls import reverse 
import secrets
from .paystack import PayStack


SEX_CHOICES = [
    ('MALE', 'Male'),
    ('FEMALE', 'Female'),
]
LEVELS_CHOICES = [
    ('Primary_level', 'Primary_level'),
    ('Secondary_level', 'Secondary_level'),
    ('Tertiary_level', 'Tertiary_level'),
]
CATEGORY_CHOICES = [
    ('Web Design and App Development', 'Web Design and App Development'),
    ('Programming and Software Engineering', 'Programming and Software Engineering'),
    ('Graphics and Video Animation', 'Graphics and Video Animation'),
    ('Design Thinking Product Development', 'Design Thinking Product Development'),
    ('STEM, Artificial Intelligence & Robotics', 'STEM, Artificial Intelligence & Robotics'),
]

LEVEL_CHOICES = [
    ('100 Level', '100 Level'),
    ('200 Level', '200 Level'),
    ('300 Level', '300 Level'),
    ('400 Level', '400 Level'),
    ('500 Level', '500 Level'),
    ('Post-Graduate', 'Post-Graduate'),
]
STATE_CHOICES = [
    ('ABUJA', 'Abuja'),
    ('OGUN', 'Ogun'),
    ('KWARA', 'Kwara'),
    ('LAGOS', 'Lagos'),
    ('KOGI', 'Kogi'),
    ('BENUE', 'Benue'),
    ('IMO', 'Imo'),
    ('OYO', 'Oyo'),
    ('JIGAWA', 'Jigawa'),
]
CLASS_CHOICES = [
    ('J.S.S.1', 'J.S.S 1'),
    ('J.S.S.2', 'J.S.S 2'),
    ('J.S.S.3', 'J.S.S 3'),
    ('S.S.S.1', 'S.S.S 1'),
    ('S.S.S.2', 'S.S.S 2'),
    ('S.S.S.3', 'S.S.S 3'),
]
CLASSES_CHOICES = [
    ('BASIC 1', 'BASIC 1'),
    ('BASIC 2', 'BASIC 2'),
    ('BASIC 3', 'BASIC 3'),
    ('BASIC 4', 'BASIC 4'),
    ('BASIC 5', 'BASIC 5'),
    ('BASIC 6', 'BASIC 6'),
]

class Bootcamp(models.Model):
    name = models.CharField(max_length=130)
    school = models.CharField(max_length=230)
    level = models.CharField(max_length=20, choices=LEVEL_CHOICES)
    categories = models.CharField(max_length=50, choices=CATEGORY_CHOICES)
    picture = models.ImageField(null=True)
    state = models.CharField(max_length=10, choices=STATE_CHOICES)
    age = models.CharField(max_length=2)
    phonenumber = models.CharField(max_length=11)
    email = models.EmailField(max_length=50)
    iT_skills_level = models.TextField(max_length=500)

    def __str__(self):
        return self.name

class SecBootcamp(models.Model):
    name = models.CharField(max_length=130)
    school = models.CharField(max_length=230)
    your_class = models.CharField(max_length=20, choices=CLASS_CHOICES)
    categories = models.CharField(max_length=50, choices=CATEGORY_CHOICES)
    picture = models.ImageField(null=True)
    state = models.CharField(max_length=10, choices=STATE_CHOICES)
    age = models.CharField(max_length=2)
    phonenumber = models.CharField(max_length=11)
    email = models.EmailField(max_length=50)
    iT_skills_level = models.TextField(max_length=500)
    parent_name = models.CharField(max_length=130)
    parent_phone_number = models.CharField(max_length=11)
    parent_email = models.EmailField(max_length=50)
    school_admin_name = models.CharField(max_length=130)
    school_admin_phone_number = models.CharField(max_length=11)

    def __str__(self):
        return self.name

class PrimaryBootcamp(models.Model):
    name = models.CharField(max_length=130)
    school = models.CharField(max_length=230)
    your_class = models.CharField(max_length=20, choices=CLASSES_CHOICES)
    categories = models.CharField(max_length=50, choices=CATEGORY_CHOICES)
    picture = models.ImageField(null=True)
    state = models.CharField(max_length=10, choices=STATE_CHOICES)
    age = models.CharField(max_length=2)
    phonenumber = models.CharField(max_length=11)
    email = models.EmailField(max_length=50)
    iT_skills_level = models.TextField(max_length=500)
    parent_name = models.CharField(max_length=130)
    parent_phone_number = models.CharField(max_length=11)
    parent_email = models.EmailField(max_length=50)
    school_admin_name = models.CharField(max_length=130)
    school_admin_phone_number = models.CharField(max_length=11)

    def __str__(self):
        return self.name

class Payment(models.Model):
    category = models.CharField(max_length=40, choices=LEVELS_CHOICES)
    amount = models.IntegerField()
    ref = models.CharField(max_length=200)
    email = models.EmailField()
    verified = models.BooleanField(default=False)
    date_created = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ('-date_created',)

    def __str__(self):
        return f"Payment: {self.amount, self.email}"
    
    def save(self,*args, **kwargs):
        while not self.ref:
            ref = secrets.token_urlsafe(20)
            object_with_similar_ref = Payment.objects.filter(ref=ref)
            if not object_with_similar_ref:
                self.ref = ref
        super().save(*args, **kwargs)

    def amount_value(self):
        return self.amount * 100

    def verify_payment(self):
        paystack = PayStack()
        status, result = paystack.verify_payment(self.ref, self.amount)
        if status:
            if result['amount'] / 100 == self.amount:
                self.verified = True
            self.save()
        if self.verified:
            return True
        return False
        