from django.contrib import admin

# Register your models here.
from .models import Bootcamp, Payment, PrimaryBootcamp, SecBootcamp

admin.site.register(SecBootcamp)
admin.site.register(PrimaryBootcamp)
admin.site.register(Bootcamp)
admin.site.register(Payment)