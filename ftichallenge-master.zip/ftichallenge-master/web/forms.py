from django import forms
from .models import Bootcamp, PrimaryBootcamp, SecBootcamp, Payment



class RegForm(forms.ModelForm):
    class Meta: 
        model = Bootcamp
        fields = ('name','school','level','categories','picture', 'state', 'age', 'phonenumber','email','iT_skills_level')

class SecRegForm(forms.ModelForm):
    class Meta: 
        model = SecBootcamp
        fields =  '__all__'
         
class PrimaryRegForm(forms.ModelForm):
    class Meta: 
        model = PrimaryBootcamp
        fields = "__all__"

class PaymentForm(forms.ModelForm):
    class Meta:
        model = Payment
        fields = ("amount","category", "email")