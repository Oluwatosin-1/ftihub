from django.http import request
from django.urls.base import reverse_lazy
from django.views.generic.edit import CreateView
from .forms import RegForm, SecRegForm, PrimaryRegForm, PaymentForm
from . import forms
from django.http.request import HttpRequest
from django.http.response import HttpResponse
from django.shortcuts import render, get_object_or_404, redirect, reverse
from django.conf import settings
from .models import Bootcamp, Payment
from django.contrib import messages

# Create your views here.
def index(request):
    return render(request, 'index.html', {})

from django.http import HttpResponseRedirect

def reg_form(request):
    title = "Registration Form For Bootcamp"
    form = RegForm(request.POST or None, request.FILES or None)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/payment/')
    else:
        form = RegForm()
    context = {
        'form':form,
        'title':title
    }
    return render(request, 'reg_form.html', context)

def sec_reg_form(request):
    title = "Registration Form For Bootcamp"
    form = SecRegForm(request.POST or None, request.FILES or None)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/payment/')
    else:
        form = SecRegForm()
    context = {
        'form':form,
        'title':title
    }
    return render(request, 'sec_reg_form.html', context)

def primary_reg_form(request):
    title = "Registration Form For Bootcamp"
    form = PrimaryRegForm(request.POST or None, request.FILES or None)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/payment/')
    else:
        form = PrimaryRegForm()
    context = {
        'form':form,
        'title':title
    }
    return render(request, 'primary_reg_form.html', context)

def initiate_payment(request: HttpRequest):
    if request.method == "POST":
        payment_form = PaymentForm(request.POST)
        if payment_form.is_valid():
            payment = payment_form.save()
            return render(request, "make_payment.html", {'payment':payment, 'paystack_public_key': settings.PAYSTACK_PUBLIC_KEY})
    else:
        payment_form = PaymentForm()
    
    return render(request, 'initiate_payment.html', {'payment_form': payment_form})

def verify_payment(request: HttpRequest, ref: str):
    payment = get_object_or_404(Payment, ref=ref)
    verified = payment.verify_payment()
    if verified:
        messages.success(request, "Verification Successful")
    else:
        messages.error(request, "verification Failed")
    return redirect('initiate_payment')