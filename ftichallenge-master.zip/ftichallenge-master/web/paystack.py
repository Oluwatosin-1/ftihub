from django.conf import settings
from django.http.response import JsonResponse 
import requests


class PayStack:
    PAYSTACK_SECRET_KEY = settings.PAYSTACK_SECRET_KEY
    base_url = 'https://api.paystack.co'

    def verify_payment(self, ref: str, *args, **kwargs):
        path = f'/transactions/verify/{ref}'
        headers = {
            "Authorization": f"Bearer {self.PAYSTACK_SECRET_KEY}",
            'Content-Type': "application/json",
        }
        url = self.base_url + path
        response = requests.get(url, headers=headers)
        response_data = requests.get(url).json()
        content = response.content
        content = self.parse_response_content(content)
        status, message = self.get_content_status(content)
        if status:
            response_data = content['data']
            return response_data['status'], response_data['data']
        response_data = response.json()
#        return response_data["status"], response_data["message"]
        return JsonResponse({"data":response.text})

#        if response.status_code == 200:
#            response_data = response.json()
#            return response_data['status'], response_data['data']
#        response_data = response.json()
#        return response_data["status"], response_data["messages"]
#https://paystack.com/pay/lj6af-ov4k
# return requests.get(self._url).json()